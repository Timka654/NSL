﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BinarySerializer.DefaultTypes
{
    public class BinaryInt64 : BasicType
    {
        public new static int GetSize(object value)
        {
            return 8;
        }
        public override bool FixedSize => true;

        public override int Size { get => 8; set { } }

        public override unsafe void GetBytes(ref byte[] buffer, int offset, object value)
        {
            fixed (byte* b = buffer)
                *((long*)(b + offset)) = (long)value;
        }

        public override unsafe object GetValue(ref byte[] buffer, int offset)
        {
            fixed (byte* pbyte = &buffer[offset])
            {
                int i1 = (*pbyte) | (*(pbyte + 1) << 8) | (*(pbyte + 2) << 16) | (*(pbyte + 3) << 24);
                int i2 = (*(pbyte + 4)) | (*(pbyte + 5) << 8) | (*(pbyte + 6) << 16) | (*(pbyte + 7) << 24);
                return (uint)i1 | ((long)i2 << 32);
            }
        }
    }
}
