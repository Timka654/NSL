﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBEngine.DBMigrator
{
    public class DBCollumnType
    {
        private static Dictionary<Type, string> Types = new Dictionary<Type, string>()
        {
            { typeof(byte), "[tinyint] NOT NULL" },
            { typeof(byte?), "[tinyint] NULL" },
            { typeof(short), "[smallint] NOT NULL" },
            { typeof(short?), "[smallint] NULL" },
            { typeof(int), "[int] NOT NULL" },
            { typeof(int?), "[int] NULL" },
            { typeof(long), "[bigint] NOT NULL" },
            { typeof(long?), "[bigint] NULL" },
            { typeof(bool), "[bit] NOT NULL" },
            { typeof(bool?), "[bit] NULL" },
            { typeof(float), "[float] NOT NULL" },
            { typeof(float?), "[float] NULL" },
            { typeof(double), "[decimal](12,8) NOT NULL" },
            { typeof(double?), "[decimal](12,8) NULL" },
            { typeof(string), "[nvarchar](max) NULL" },
            { typeof(Enum), "[int] NOT NULL" },
            { typeof(DateTime), "[smalldatetime] NOT NULL" },
            { typeof(TimeSpan), "[bigint] NOT NULL" },
        };

        internal static Dictionary<Type, Func<object, string>> SqlGetterFuncMap = new Dictionary<Type, Func<object, string>>()
        {
            { typeof(byte), (v)=>{ return v.ToString(); } },
            { typeof(short), (v)=>{ return v.ToString(); } },
            { typeof(int), (v)=>{ return v == null? "0" : v.ToString(); } },
            { typeof(long), (v)=>{ return v == null? "0" : v.ToString(); } },
            { typeof(bool), (v)=>{ return ((bool)v? 1 : 0).ToString(); } },
            { typeof(float), (v)=>{ return v.ToString().Replace(',','.'); } },
            { typeof(double), (v)=>{ return v.ToString().Replace(',','.'); } },
            { typeof(string), (v)=>{ return $"'{((string)v)}'"; } },
            { typeof(Enum), (v)=>{ return ((int)v).ToString(); } },
            { typeof(DateTime), (v)=>{ return ((DateTime)v).ToString(); } },
            { typeof(TimeSpan), (v)=>{ return ((TimeSpan)v).TotalMilliseconds.ToString(); } },
        };

        internal static Dictionary<Type, Func<Object>> TypeDefaultValues = new Dictionary<Type, Func<object>>()
        {
            { typeof(byte), ()=>{ return 0; } },
            { typeof(short), ()=>{ return 0; } },
            { typeof(int), ()=>{ return 0; } },
            { typeof(long), ()=>{ return 0; } },
            { typeof(bool), ()=>{ return false; } },
            { typeof(float), ()=>{ return 0; } },
            { typeof(double), ()=>{ return 0; } },
            { typeof(string), ()=>{ return 0; } },
            { typeof(Enum), ()=>{ return 0; } },
            { typeof(DateTime), ()=>{ return DateTime.MinValue; } },
            { typeof(TimeSpan), ()=>{ return default(TimeSpan); } },
        };

        public static string GetSQLType(string table, DBCollumnAttribute collumn, bool alter = false)
        {
            if (!Types.ContainsKey(collumn.Type))
                throw new InvalidCastException($"Table:{table} Collumn:{collumn.Name} have not supported sqlType");
            var r = Types[collumn.Type];

            if (alter)
                if (r.EndsWith("NOT NULL"))
                    r += $" default ({SqlGetterFuncMap[collumn.Type](TypeDefaultValues[collumn.Type]())})";

            return Types[collumn.Type];
        }

    }
}
