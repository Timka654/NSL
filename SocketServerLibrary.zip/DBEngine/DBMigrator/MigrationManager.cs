﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Reflection;
using System.Collections;
using System.Data.Common;

namespace DBEngine.DBMigrator
{
    /*
     * Entity Framework курильщика
    */
    public class MigrationManager<T, TSelectAttribute>
        where T : DbConnection
        where TSelectAttribute : DBAutoMigrationAttribute
    {
        private static DbConnectionPool<T> connPool;
        
        #region Properties

        private static string ConnectionString;

        #endregion

        public static void UpdateDb(Assembly assembly, DbConnectionPool<T> connect_pool)
        {
            connPool = connect_pool;
            var classes = assembly.GetTypes().Select(x => new { type = x, attr = x.GetCustomAttribute<TSelectAttribute>() }).Where(x => x.attr != null).OrderBy(x => x.attr.Order != 0).OrderBy(x => x.attr.Order).ToList();
            foreach (var item in classes)
            {
                typeof(MigrationManager<T, TSelectAttribute>).GetMethod("UpdateDbGenericConfig", BindingFlags.NonPublic | BindingFlags.Static).MakeGenericMethod(item.type).Invoke(null, null);
            }
            return;
        }

        private static void UpdateDbGenericConfig<TQ>() where TQ : DBIdentityEntity
        {
            var type = MigrationTypeInfo.LoadType(typeof(TQ), new List<TQ>());
            MigrationTypeInfo.FillIds(type);
            UpdateDbGeneric<TQ>(type, 0);
        }

        private static void UpdateDbGeneric<TQ>(MigrationTypeInfo type, object foreignValue)
        {
            //if (type.IdCollumn != null && type.IsBaseConfig)
            //    MigrationTypeInfo.FillIds(type);
            if (type.Collumns.Count == 0)
                return;

            string query = $@"IF (not EXISTS (SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES
                 WHERE TABLE_SCHEMA = 'dbo'
                 AND TABLE_NAME = '{type.TableName}'))
                BEGIN
                {GetCreationQuery(type)}
                END" + "\r\n\r\n\r\n\r\n" + GetExistSegment(type) + "\r\n\r\n\r\n\r\n";

            if (type.HaveForeign && !type.HaveId)
            {
                if (type.ForeignCollumn != null)
                {
                    List<string> segments = new List<string>();

                    segments.Add($"{type.ForeignKey} = {(DBCollumnType.SqlGetterFuncMap[type.ForeignCollumn.type](foreignValue))}");

                    if(type.SourceKeys != null)
                    foreach (var item in type.SourceKeys)
                    {
                        segments.Add($"{item.DestinationCollumnName} = {(DBCollumnType.SqlGetterFuncMap[item.SourceValue.GetType()](item.SourceValue))}");
                    }
                    string where = string.Join(" and ", segments);

                    query += $"Delete from dbo.{type.TableName} where {where}\r\n";
                }
            }

            var insert_collumn_fragment = GetInsertCollumns(type);
            if (type.HaveForeign && type.ForeignCollumn == null)
            {
                insert_collumn_fragment.Add($"[{type.ForeignKey}]");
            }
            DBCommand cm = connPool.GetCommand();
            cm.Query = query;
            cm.Execute();
            query = "";


            foreach (var item in type.Values)
            {
                List<string> update_fragment = new List<string>();
                List<string> insert_fragment = new List<string>();

                if (type.HaveForeign && type.ForeignCollumn == null)
                {
                    update_fragment.Add($"{type.ForeignKey} = {foreignValue}");
                    insert_fragment.Add(foreignValue.ToString().Replace(',', '.'));
                }
                else if (type.HaveForeign)
                {
                    type.ForeignCollumn.setter(item, foreignValue);
                }
                update_fragment.AddRange(GetUpdateValues(type, item));

                insert_fragment.AddRange(GetInsertValues(type, item));

                if (update_fragment.Count == 0 || insert_collumn_fragment.Count == 0 || insert_fragment.Count == 0)
                    continue;

                string where = GetWhereSegment(type, item, foreignValue);

                query += $"IF ((Select Count(*) from dbo.{type.TableName} where {where} ) = 1) BEGIN \r\n " +
                    $"Update dbo.{type.TableName} set {string.Join(",", update_fragment.ToArray())} \r\n " +
                    $"where {where}\r\n " +
                    $"END\r\nElSE\r\nBEGIN\r\n " +
                    $"Insert into dbo.{type.TableName} ({string.Join(",", insert_collumn_fragment.ToArray())}) Values ({string.Join(",", insert_fragment.ToArray())})\r\n " +
                    $"END\r\n ";
            }
            cm.Query = query;
            if (!string.IsNullOrEmpty(cm.Query))
                cm.Execute();
            cm.CloseConnection();

            foreach (var item in type.Collumns)
            {
                ForeignFill(item, type, null);
            }

        }

        private static void ForeignFill(CollumnInfo collumn, MigrationTypeInfo type, object foreignKeyValue)
        {
            if (!collumn.IsAppendTable && collumn.foreign_attribute == null)
                return;
            bool nullKey = foreignKeyValue == null;
            foreach (var item in type.Values)
            {

                if (type.IdCollumn != null && nullKey)
                    foreignKeyValue = type.IdCollumn.getter(item);


                if (collumn.IsAppendTable)
                {
                    collumn.MigrationTypeInfo.Values = new[] { collumn.getter(item) };
                    foreach (var col in collumn.MigrationTypeInfo.Collumns)
                    {
                        ForeignFill(col, collumn.MigrationTypeInfo, foreignKeyValue);
                    }
                    continue;
                }

                if (collumn.foreign_attribute == null)
                    continue;


                collumn.MigrationTypeInfo.Values = (IEnumerable)collumn.getter(item);

                if (collumn.MigrationTypeInfo.SourceKeys != null && collumn.MigrationTypeInfo.Values != null)
                    foreach (var sourceKey in collumn.MigrationTypeInfo.SourceKeys)
                    {
                        sourceKey.SourceValue = type.Collumns.Find(x => x.collumn_attribute.Name == sourceKey.SourceCollumnName).getter(item);

                        foreach (var value in collumn.MigrationTypeInfo.Values)
                        {
                            collumn.MigrationTypeInfo.Collumns.Find(x => x.collumn_attribute.Name == sourceKey.DestinationCollumnName).setter(value, sourceKey.SourceValue);
                        }
                    }

                typeof(MigrationManager<T, TSelectAttribute>).GetMethod("UpdateDbGeneric", BindingFlags.NonPublic | BindingFlags.Static).MakeGenericMethod(collumn.type).Invoke(null, new object[] { collumn.MigrationTypeInfo, foreignKeyValue });
            }

            foreach (var item in type.Values)
            {
                return;
            }

            if (collumn.IsAppendTable)
            {
                foreach (var col in collumn.MigrationTypeInfo.Collumns)
                {
                    ForeignFill(col, collumn.MigrationTypeInfo, foreignKeyValue);
                }
                return;
            }

            if (collumn.foreign_attribute == null)
                return;



            if (collumn.MigrationTypeInfo.SourceKeys != null && collumn.MigrationTypeInfo.Values != null)
                foreach (var sourceKey in collumn.MigrationTypeInfo.SourceKeys)
                {
                    //sourceKey.SourceValue = type.Collumns.Find(x => x.collumn_attribute.Name == sourceKey.SourceCollumnName).getter(item);

                    foreach (var value in collumn.MigrationTypeInfo.Values)
                    {
                        collumn.MigrationTypeInfo.Collumns.Find(x => x.collumn_attribute.Name == sourceKey.DestinationCollumnName).setter(value, sourceKey.SourceValue);
                    }
                }

            typeof(MigrationManager<T, TSelectAttribute>).GetMethod("UpdateDbGeneric", BindingFlags.NonPublic | BindingFlags.Static).MakeGenericMethod(collumn.type).Invoke(null, new object[] { collumn.MigrationTypeInfo, foreignKeyValue });
        }

        #region Utils

        private static string GetWhereSegment(MigrationTypeInfo t, object item, object foreignValue)
        {
            List<string> where_fragment = new List<string>();

            if (t.HaveId)
                where_fragment.Add($"{t.IdKey} = {DBCollumnType.SqlGetterFuncMap[t.IdCollumn.type](t.IdCollumn.getter(item))}");
            if (t.HaveForeign)
                where_fragment.Add($"{t.ForeignKey} = {foreignValue}");

            return string.Join(" and ", where_fragment.ToArray());
        }

        private static object GetValue(PropertyInfo property, object obj)
        {
            if (property.PropertyType.IsEnum)
                return Convert.ToInt32(property.GetValue(obj));
            return property.GetValue(obj);
        }

        private static object GetValue(FieldInfo property, object obj)
        {
            if (property.FieldType.IsEnum)
                return Convert.ToInt32(property.GetValue(obj));
            return property.GetValue(obj);
        }

        private static List<string> GetInsertCollumns(MigrationTypeInfo t)
        {
            List<string> insert_fragment = new List<string>();

            foreach (var collumn in t.Collumns)
            {
                if (!collumn.IsAppendTable && !collumn.IsMigrationType)
                {
                    if (collumn.collumn_attribute.Type == null)
                        collumn.collumn_attribute.Type = collumn.type;

                    insert_fragment.Add($"[{collumn.collumn_attribute.Name}]");
                }
                else if (collumn.IsAppendTable)
                    insert_fragment.AddRange(GetInsertCollumns(collumn.MigrationTypeInfo));
            }

            return insert_fragment;
        }

        private static List<string> GetCreateCollumns(MigrationTypeInfo t)
        {
            List<string> create_fragment = new List<string>();

            foreach (var collumn in t.Collumns)
            {
                if (collumn.collumn_attribute != null)
                {
                    if (collumn.collumn_attribute.Type == null)
                        collumn.collumn_attribute.Type = collumn.type;

                    create_fragment.Add($"[{collumn.collumn_attribute.Name}] {DBCollumnType.GetSQLType(t.TableName, collumn.collumn_attribute)}");
                }
                else if (collumn.IsAppendTable)
                    create_fragment.AddRange(GetCreateCollumns(collumn.MigrationTypeInfo));
            }

            return create_fragment;
        }

        private static List<string> GetExistCollumns(MigrationTypeInfo t, string table_name)
        {
            List<string> exist_fragment = new List<string>();

            foreach (var collumn in t.Collumns)
            {
                if (collumn.collumn_attribute != null)
                {
                    if (collumn.collumn_attribute.Type == null)
                        collumn.collumn_attribute.Type = collumn.type;

                    exist_fragment.Add($@"IF ((Select Count(*) from sys.columns where object_id = OBJECT_ID('dbo.{table_name}') and name like '{collumn.collumn_attribute.Name}') = 0) BEGIN 
                ALTER TABLE {table_name}
                    ADD [{collumn.collumn_attribute.Name}] {DBCollumnType.GetSQLType(t.TableName, collumn.collumn_attribute,true)}
            END");
                }
                else if (collumn.IsAppendTable)
                    exist_fragment.AddRange(GetExistCollumns(collumn.MigrationTypeInfo, table_name));
            }

            return exist_fragment;
        }

        private static List<string> GetUpdateValues(MigrationTypeInfo t, object item)
        {
            List<string> update_fragment = new List<string>();

            foreach (var collumn in t.Collumns)
            {
                if (collumn.IsAppendCollumn && collumn.append_collumn_attribute.AutoIncrement)
                    t[item, collumn.collumn_attribute.Name] = collumn.append_collumn_attribute.Increment();

                if (DBCollumnType.SqlGetterFuncMap.ContainsKey(collumn.type))
                    update_fragment.Add(collumn.collumn_attribute.Name + " = " + DBCollumnType.SqlGetterFuncMap[collumn.type](collumn.getter(item)));
                else if (collumn.IsAppendTable)
                    update_fragment.AddRange(GetUpdateValues(collumn.MigrationTypeInfo, collumn.getter(item)));
            }

            return update_fragment;

        }

        private static List<string> GetInsertValues(MigrationTypeInfo t, object item)
        {
            List<string> insert_fragment = new List<string>();
            if (item == null)
                return insert_fragment;

            foreach (var collumn in t.Collumns)
            {
                if (DBCollumnType.SqlGetterFuncMap.ContainsKey(collumn.type))
                    insert_fragment.Add(DBCollumnType.SqlGetterFuncMap[collumn.type](collumn.getter(item)));
                else if (collumn.IsAppendTable)
                    insert_fragment.AddRange(GetInsertValues(collumn.MigrationTypeInfo, collumn.getter(item)));

            }

            return insert_fragment;
        }

        private static string GetCreationQuery(MigrationTypeInfo t)
        {
            List<string> create_fragment = GetCreateCollumns(t);

            if (t.HaveForeign && t.ForeignCollumn == null)
                create_fragment.Add($"[{t.ForeignKey}] [int] NOT NULL");

            return $"Create Table [dbo].[{t.TableName}] (\r\n {string.Join(",\r\n", create_fragment.ToArray())} \r\n)";
        }

        private static string GetExistSegment(MigrationTypeInfo t)
        {
            return string.Join("\r\n", GetExistCollumns(t, t.TableName).ToArray());


        }

        #endregion

        public class MigrationTypeInfo
        {
            public Type Type { get; set; }

            public List<CollumnInfo> Collumns { get; private set; }

            public bool HaveId { get; private set; }

            public bool HaveForeign { get; private set; }

            public string TableName { get; set; }

            public bool IsBaseConfig { get; private set; }

            public string IdKey { get; private set; } = "id";

            public string ForeignKey { get; private set; }

            public object ForeiegnValue { get; private set; }

            public CollumnInfo IdCollumn { get; private set; }

            public CollumnInfo ForeignCollumn { get; private set; }

            public DBCollumnForeignKeyAttribute[] SourceKeys { get; private set; }

            public IEnumerable Values { get; set; }

            public static MigrationTypeInfo LoadType(Type t, IEnumerable values, DBCollumnForeignAttribute foreignKey = null, DBSealedCollumnAttribute[] sealed_collumns = null, string[] prefixes = null, DBCollumnForeignKeyAttribute[] foreignKeys = null)
            {
                var r = new MigrationTypeInfo();

                r.Type = t;

                var tableAttr = r.Type.GetCustomAttribute<DBTableAttribute>();

                if (tableAttr != null)
                {
                    r.IdKey = tableAttr.IdCollumn;
                    r.TableName = tableAttr.Name;
                    if (prefixes == null)
                        prefixes = tableAttr.Prefixes;
                }

                r.Values = values;
                r.Collumns = GetCollumns(t, foreignKey, sealed_collumns, prefixes, foreignKeys);
                r.SourceKeys = foreignKeys;
                r.HaveForeign = !string.IsNullOrEmpty(foreignKey?.Name);
                r.HaveId = r.Collumns.Exists(x => x.collumn_attribute?.Name == r.IdKey || x.append_collumn_attribute?.Name == r.IdKey);

                r.IsBaseConfig = (typeof(DBIdentityEntity)).IsAssignableFrom(t);

                var ignored = (DBMigrationIgnoreFieldsAttribute)Attribute.GetCustomAttribute(t, typeof(DBMigrationIgnoreFieldsAttribute));

                if (tableAttr != null && foreignKey == null && ignored != null)
                {

                    r.Collumns = r.Collumns.Where(x => !ignored.NameArray.Contains(x.property.Name)).ToList();
                }

                if (r.HaveId)
                {
                    r.IdCollumn = r.Collumns.FirstOrDefault(x => x.collumn_attribute?.Name == r.IdKey || x.append_collumn_attribute?.Name == r.IdKey);

                }

                if (r.HaveForeign)
                {
                    r.ForeignKey = foreignKey.Name;
                    r.ForeignCollumn = r.Collumns.FirstOrDefault(x => x.collumn_attribute?.Name == foreignKey.Name || x.append_collumn_attribute?.Name == foreignKey.Name);
                }

                return r;
            }

            public static void FillIds(MigrationTypeInfo type)
            {
                var list = type.Values as IEnumerable<DBIdentityEntity>;

                list = list.OrderBy(x => x.GetIndex() != 0).OrderBy(x => x.GetIndex()).ToList();

                int temp = 0;

                foreach (var item in list)
                {
                    ++temp;
                    if (item.GetIndex() != temp)
                        item.SetIndex(temp);
                }
            }

            private static CollumnInfo GetCollumn(PropertyInfo x)
            {
                return GetCollumnAttributes(new CollumnInfo
                {
                    property = x,
                    type = x.PropertyType,
                    getter = new Func<object, object>((object obj) => { return GetValue(x, obj); }),
                    setter = new Action<object, object>((object obj, object val) => { x.SetValue(obj, val); })
                });
            }

            private static CollumnInfo GetCollumn(FieldInfo x)
            {
                return GetCollumnAttributes(new CollumnInfo
                {
                    property = x,
                    type = x.FieldType,
                    getter = new Func<object, object>((object obj) => { return GetValue(x, obj); }),
                    setter = new Action<object, object>((object obj, object val) => { x.SetValue(obj, val); })
                });
            }

            private static CollumnInfo GetCollumnAttributes(CollumnInfo collumn)
            {
                collumn.collumn_attribute = (DBCollumnAttribute)Attribute.GetCustomAttribute(collumn.property, typeof(DBCollumnAttribute));
                collumn.foreign_attribute = (DBCollumnForeignAttribute)Attribute.GetCustomAttribute(collumn.property, typeof(DBCollumnForeignAttribute));
                collumn.append_table_attribute = (DBAppendTableAttribute)Attribute.GetCustomAttribute(collumn.property, typeof(DBAppendTableAttribute));

                return collumn;
            }

            private static List<CollumnInfo> GetCollumns(Type t, DBCollumnForeignAttribute foreignKey, DBSealedCollumnAttribute[] append_collumns, string[] prefixes, DBCollumnForeignKeyAttribute[] foreignKeys)
            {
                List<CollumnInfo> r = new List<CollumnInfo>();

                if (foreignKey?.Sealed != true)
                {
                    r.AddRange(t.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance |
                               BindingFlags.DeclaredOnly)
                        .Where(x =>
                        (Attribute.GetCustomAttribute(x, typeof(DBCollumnAttribute)) != null ||
                        Attribute.GetCustomAttribute(x, typeof(DBCollumnForeignAttribute)) != null ||
                        Attribute.GetCustomAttribute(x, typeof(DBAppendTableAttribute)) != null)
                        )
                        .Select(x => GetCollumn(x)).ToList());

                    r.AddRange(t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance |
                               BindingFlags.DeclaredOnly)
                        .Where(x =>
                        (Attribute.GetCustomAttribute(x, typeof(DBCollumnAttribute)) != null ||
                        Attribute.GetCustomAttribute(x, typeof(DBCollumnForeignAttribute)) != null ||
                        Attribute.GetCustomAttribute(x, typeof(DBAppendTableAttribute)) != null)
                        )
                        .Select(x => GetCollumn(x)).ToList());

                    FillPrefixes(r, foreignKey?.ForeignPrefixes, prefixes, foreignKeys);

                    foreach (var item in r)
                    {
                        if (item.type.IsGenericType && item.type.GetGenericTypeDefinition() == typeof(List<>))
                            item.type = item.type.GetGenericArguments()[0];

                        if (item.type.BaseType == typeof(Enum))
                            item.type = typeof(Enum);

                        if (item.foreign_attribute != null)
                        {
                            item.IsMigrationType = true;

                            item.MigrationTypeInfo = LoadType(item.type, new List<object>(), foreignKey: item.foreign_attribute, sealed_collumns: Attribute.GetCustomAttributes(item.property, typeof(DBSealedCollumnAttribute)).Cast<DBSealedCollumnAttribute>().ToArray(), prefixes: prefixes);

                            item.MigrationTypeInfo.TableName = item.foreign_attribute.Table;

                            foreach (DBAppendCollumnAttribute col in Attribute.GetCustomAttributes(item.property, typeof(DBAppendCollumnAttribute)))
                            {
                                var c = new CollumnInfo()
                                {
                                    append_collumn_attribute = col,
                                    collumn_attribute = new DBCollumnAttribute(col.Name) { Type = col.Type },
                                    IsAppendCollumn = true,
                                    IsMigrationType = false,
                                    IsAppendTable = false,
                                    type = col.Type
                                };
                                c.setter = (obj, val) =>
                                {
                                    item.MigrationTypeInfo[obj, c.append_collumn_attribute.Name] = val;
                                };
                                c.getter = (obj) =>
                                {
                                    return item.MigrationTypeInfo[obj, c.append_collumn_attribute.Name];
                                };
                                item.MigrationTypeInfo.Collumns.Add(c);
                            }

                            FillPrefixes(item.MigrationTypeInfo.Collumns, foreignKey?.ForeignPrefixes, prefixes, foreignKeys);
                            item.MigrationTypeInfo.HaveId = item.MigrationTypeInfo.Collumns.Exists(x => x.collumn_attribute?.Name == item.MigrationTypeInfo.IdKey || x.append_collumn_attribute?.Name == item.MigrationTypeInfo.IdKey);

                            if (item.MigrationTypeInfo.HaveId)
                            {
                                item.MigrationTypeInfo.IdCollumn = item.MigrationTypeInfo.Collumns.FirstOrDefault(x => x.collumn_attribute?.Name == item.MigrationTypeInfo.IdKey || x.append_collumn_attribute?.Name == item.MigrationTypeInfo.IdKey);
                            }

                            if (item.MigrationTypeInfo.HaveForeign)
                            {
                                item.MigrationTypeInfo.ForeignKey = item.foreign_attribute.Name;
                                item.MigrationTypeInfo.ForeignCollumn = item.MigrationTypeInfo.Collumns.FirstOrDefault(x => x.collumn_attribute?.Name == item.foreign_attribute.Name || x.append_collumn_attribute?.Name == item.foreign_attribute.Name);
                            }
                        }
                        else if (item.append_table_attribute != null)
                        {
                            item.IsAppendTable = true;
                            item.MigrationTypeInfo = LoadType(item.type, new List<object>(), sealed_collumns: Attribute.GetCustomAttributes(item.property, typeof(DBSealedCollumnAttribute)).Cast<DBSealedCollumnAttribute>().ToArray(), prefixes: prefixes);
                        }
                    }
                }

                if (append_collumns != null)
                {
                    CollumnInfo collumn = null;
                    foreach (var item in append_collumns)
                    {
                        var prop = t.GetProperty(item.MemberName);
                        if (prop == null)
                        {
                            var field = t.GetField(item.MemberName);
                            if (field != null)
                                collumn = GetCollumn(field);
                        }
                        else
                        {
                            collumn = GetCollumn(prop);
                        }

                        collumn.collumn_attribute = new DBCollumnAttribute(item.Name) { Type = item.Type };

                        r.Add(collumn);
                    }
                }

                FillPrefixes(r, foreignKey?.ForeignPrefixes, prefixes, foreignKeys);

                foreach (var item in r)
                {
                    var ignored = (DBMigrationIgnoreFieldsAttribute)Attribute.GetCustomAttribute(item.property, typeof(DBMigrationIgnoreFieldsAttribute));
                    if (ignored == null)
                        continue;

                    item.MigrationTypeInfo.Collumns.RemoveAll(x => x.property != null && ignored.NameArray.Contains(x.property.Name));
                }

                return r;
            }

            private static void FillPrefixes(List<CollumnInfo> r, string[] foreignPrefixes, string[] prefixes, DBCollumnForeignKeyAttribute[] foreignKeys)
            {
                if (prefixes != null && prefixes.Length != 0)
                {
                    if (foreignKeys != null)
                        foreach (var item in foreignKeys)
                        {
                            for (int i = 0; i < prefixes.Length; i++)
                            {
                                int p = i + 1;
                                item.DestinationCollumnName = item.DestinationCollumnName.Replace($"{{*Prefix{p}}}", prefixes[i]);
                                item.SourceCollumnName = item.SourceCollumnName.Replace($"{{*Prefix{p}}}", prefixes[i]);
                            }
                        }

                    foreach (var item in r)
                    {
                        for (int i = 0; i < prefixes.Length; i++)
                        {
                            int p = i + 1;
                            if (item.collumn_attribute != null)
                            {
                                item.collumn_attribute.Name = item.collumn_attribute.Name.Replace($"{{*Prefix{p}}}", prefixes[i]);
                            }

                            if (item.append_collumn_attribute != null)
                            {
                                item.append_collumn_attribute.Name = item.append_collumn_attribute.Name.Replace($"{{*Prefix{p}}}", prefixes[i]);
                            }

                            if (item.foreign_attribute != null)
                            {
                                item.foreign_attribute.Name = item.foreign_attribute.Name.Replace($"{{*Prefix{p}}}", prefixes[i]);
                                item.foreign_attribute.Table = item.foreign_attribute.Table.Replace($"{{*Prefix{p}}}", prefixes[i]);
                            }
                        }
                    }
                }


                if (foreignPrefixes != null && foreignPrefixes.Length != 0)
                {
                    if (foreignKeys != null)
                        foreach (var item in foreignKeys)
                        {
                            for (int i = 0; i < foreignPrefixes.Length; i++)
                            {
                                int p = i + 1;
                                item.DestinationCollumnName = item.DestinationCollumnName.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                                item.SourceCollumnName = item.SourceCollumnName.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                            }
                        }

                    foreach (var item in r)
                    {
                        for (int i = 0; i < foreignPrefixes.Length; i++)
                        {
                            int p = i + 1;
                            if (item.collumn_attribute != null)
                            {
                                item.collumn_attribute.Name = item.collumn_attribute.Name.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                            }

                            if (item.append_collumn_attribute != null)
                            {
                                item.append_collumn_attribute.Name = item.append_collumn_attribute.Name.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                            }

                            if (item.foreign_attribute != null)
                            {
                                item.foreign_attribute.Name = item.foreign_attribute.Name.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                                item.foreign_attribute.Table = item.foreign_attribute.Table.Replace($"{{*ForeignPrefix{p}}}", foreignPrefixes[i]);
                            }
                        }
                    }
                }
            }

            public object this[object item, string name]
            {
                get
                {
                    object o = null;
                    if (!AppendedValues.TryGetValue(new KeyValuePair<string, object>(name, item), out o))
                    {
                        o = Activator.CreateInstance(Collumns.FirstOrDefault(x => x.append_collumn_attribute?.Name == name).type);
                    }
                    return o;
                }
                set
                {
                    var id = new KeyValuePair<string, object>(name, item);
                    if (AppendedValues.ContainsKey(id))
                        AppendedValues[id] = value;
                    else
                        AppendedValues.Add(id, value);
                }
            }

            private Dictionary<KeyValuePair<string, object>, object> AppendedValues = new Dictionary<KeyValuePair<string, object>, object>();

            public override string ToString()
            {
                return TableName;
            }
        }

        public class CollumnInfo
        {
            public MemberInfo property;

            public Type type;

            public DBCollumnAttribute collumn_attribute;

            public DBAppendCollumnAttribute append_collumn_attribute;

            public DBCollumnForeignAttribute foreign_attribute;

            public DBAppendTableAttribute append_table_attribute;

            public DBCollumnForeignKeyAttribute[] foreign_key_attributes;

            public Func<object, object> getter;

            public Action<object, object> setter;

            public bool IsMigrationType;

            public bool IsAppendTable;

            public bool IsAppendCollumn;

            public MigrationTypeInfo MigrationTypeInfo;

            public override string ToString()
            {
                return $"{collumn_attribute?.Name} ({property?.Name})";
            }
        }
    }
}