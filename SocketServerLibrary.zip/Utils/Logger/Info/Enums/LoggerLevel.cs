﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Logger
{
    public enum LoggerLevel
    {
        Info,
        Error,
        Log,
        Debug,
        Performance
    }
}
