﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Query
{
    public class LobbyServerStaticQueryLoadAttribute : StaticQueryLoadAttribute
    {
        public LobbyServerStaticQueryLoadAttribute(int order, string name) : base(order, name)
        {
        }
    }
}
