﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class LoginServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public LoginServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
