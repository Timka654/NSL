﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class RoomServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public RoomServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
