﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class ClientServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public ClientServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
