﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class AuthServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public AuthServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
