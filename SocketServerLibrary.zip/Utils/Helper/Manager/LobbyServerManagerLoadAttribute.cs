﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class LobbyServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public LobbyServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
