﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils.Helper.Manager
{
    public class GameServerManagerLoadAttribute : ManagerLoadAttribute
    {
        public GameServerManagerLoadAttribute(int offset) : base(offset)
        {
        }
    }
}
