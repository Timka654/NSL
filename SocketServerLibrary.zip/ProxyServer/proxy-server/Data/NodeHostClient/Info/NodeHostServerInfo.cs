﻿using ps.Data.NodeHostClient.Network;
using System;
using System.Collections.Generic;
using System.Text;

namespace ps.Data.NodeHostClient.Info
{
    public class NodeHostClientInfo
    {
        public NetworkNodeHostClientData Network { get; set; }
    }
}
