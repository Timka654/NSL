﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ps.Data.NodeServer.Info
{
    public enum LoginResultEnum
    {
        Error,
        Ok
    }
}
