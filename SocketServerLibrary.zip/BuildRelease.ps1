#$ver = $args[0]
#dotnet pack --configuration Release --output "nupkg" --version-suffix "$ver" SSF.sln