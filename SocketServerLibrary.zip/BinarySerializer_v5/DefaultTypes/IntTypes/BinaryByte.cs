﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Linq;
using GrEmit;
using GrEmit.Utils;

namespace BinarySerializer.DefaultTypes
{
    /// <summary>
    /// Version v4
    /// </summary>
    public class BinaryByte : BinaryInt8
    {
    }
}
