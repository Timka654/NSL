$ver = $args[0]
dotnet build "SSF.sln"
dotnet pack --configuration Debug --output "nupkg" --version-suffix "$ver" SSF.sln