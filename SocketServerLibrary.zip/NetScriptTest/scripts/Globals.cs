﻿#if !CompileScript
public class Globals
{
    public NetScriptTest.TScript Character { get; set; }
}
#endif
