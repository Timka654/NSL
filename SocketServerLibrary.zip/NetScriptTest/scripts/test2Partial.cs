﻿public partial class test2
{
    public void TestPartial()
    {
        global.Character.Debug(string.Format("init test {0}", global.Character.ID));
    }
}