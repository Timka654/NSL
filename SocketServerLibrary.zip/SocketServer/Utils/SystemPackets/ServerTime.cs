﻿using System;
using System.Collections.Generic;
using System.Text;
using SocketServer.Utils.Buffer;

namespace SocketServer.Utils.SystemPackets
{
    public class ServerTime
    {        
        public static void Send(INetworkClient client)
        {
            client.AliveState = false;
            client.Alive_locker.Reset();

            var packet = new OutputPacketBuffer()
            {
                PacketId = (ushort)Enums.ClientPacketEnum.ServerTime
            };
            client.Network.Send(packet);

            client.Alive_locker.WaitOne(3000);
            if (!client.AliveState)
                client.Network.Disconnect();
        }
    }
}
