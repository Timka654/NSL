﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCL.Unity.NAT.Proxy.ProxyNetwork.Data.Packets.Enums
{
    internal enum ClientPacketsEnum : ushort
    {
        SignInResult = 1,
    }
}
