﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCL.Unity.NAT.Proxy.ProxyNetwork.Data.Info.Enums
{
    public enum ProxySignInResultEnum
    {
        CannotConnected,
        InvalidClientData,
        Ok
    }
}
