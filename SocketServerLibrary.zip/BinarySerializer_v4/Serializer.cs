﻿using BinarySerializer.DefaultTypes;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BinarySerializer
{
    public partial class BinarySerializer
    {
        public byte[] Serialize<T>(string schemeName, T value, int len = 32)
        {
            buffer = new byte[len];
            offset = 0;

            Serialize(schemeName, value, typeStorage.GetTypeInfo(schemeName, typeof(T), TypeInstanceMap));

            return buffer;
        }

        public byte[] Serialize(string schemeName,object value, int len = 32)
        {
            buffer = new byte[len];
            offset = 0;
            
            Serialize(schemeName,value, typeStorage.GetTypeInfo(schemeName, value.GetType(), TypeInstanceMap));

            return buffer;
        }

        private void Serialize(string schemeName, object value, List<PropertyData> props)
        {
            foreach (var item in props)
            {
                if (item.Attrib.Type.BaseType == typeof(BasicType))
                {
                    if (!item.Type.FixedSize)
                    {
                        if (!item.Type.FixedSize && item.DynamicTypeSizeProperty != null)
                            item.Type.Size = item.Size = Convert.ToInt32(item.DynamicTypeSizeProperty.Getter(value));
                        else
                            item.Size = item.Attrib.TypeSize;
                    }
                    
                    if (item.Attrib.ArraySize> 0 || item.Attrib.ArraySizeName != null)
                    {
                        WriteArrayPrimitive(value, item);
                        continue;
                    }
                    

                    WritePrimitive(value, item);
                }
                else
                {
                    if (item.DynamicArraySizeProperty != null || item.Attrib.ArraySize > 0)
                    {
                        WriteArrayType(schemeName, value, item);
                        continue;
                    }

                    WriteType(schemeName,item.Getter(value), item);
                }
            }
        }

        private void WriteArrayPrimitive(object value, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = Convert.ToInt32(prop_data.DynamicArraySizeProperty.Getter(value));

            if (arr_len == 0)
                return;

            int offsetlen = prop_data.Size * arr_len;

            while (buffer.Length - offset < offsetlen)
            {
                Array.Resize(ref buffer, buffer.Length * 2);
            }

            var f_array = (ICollection)prop_data.Getter(value);
            string pname = prop_data.Property.Name;
            int i = 0;

            foreach (var item in f_array)
            {
                if (arr_len < ++i)
                    break;
                    prop_data.Type.GetBytes(ref buffer, offset, item);
                offset += prop_data.Size;
            }

            if (arr_len > f_array.Count)
                offset += prop_data.Size * (arr_len - f_array.Count);
        }

        private void WritePrimitive(object value, PropertyData prop_data)
        {
            while (buffer.Length - offset < prop_data.Size)
            {
                Array.Resize(ref buffer, buffer.Length * 2);
            }

            prop_data.Type.GetBytes(ref buffer, offset, prop_data.Getter(value));
            offset += prop_data.Size;
        }

        private void WriteArrayType(string schemeName, object value, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = Convert.ToInt32(prop_data.DynamicArraySizeProperty.Getter(value));

            var f_array = (ICollection)prop_data.Getter(value);

            int q = 0;

            foreach (var item in f_array)
            {
                if (arr_len < ++q)
                    break;
                WriteType(schemeName,item, prop_data);
            }

            if (arr_len > f_array.Count)
                for (int i = f_array.Count; i < arr_len; i++)
                {
                    WriteType(schemeName, Activator.CreateInstance(prop_data.Attrib.Type), prop_data);
                }
        }

        private void WriteType(string schemeName, object value, PropertyData prop_data)
        {
            Serialize(schemeName,value ?? Activator.CreateInstance(prop_data.Attrib.Type),typeStorage.GetTypeInfo(schemeName, prop_data.Attrib.Type, TypeInstanceMap));
        }
    }
}
