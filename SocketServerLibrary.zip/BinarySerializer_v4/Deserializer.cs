﻿using BinarySerializer.DefaultTypes;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace BinarySerializer
{public partial class BinarySerializer
    {
        public T Deserialize<T>(string schemeName, byte[] buffer, int offset = 0)
        {
            this.buffer = buffer;
            this.offset = offset;

            return _Deserialize<T>(schemeName);
        }

        private object Deserialize(string schemeName, Type type, List<PropertyData> props)
        {
            object r = Activator.CreateInstance(type);

            BasicType tinst = null;

            foreach (var item in props)
            {
                if (TypeInstanceMap.ContainsKey(item.Attrib.Type))
                {
                    tinst = TypeInstanceMap[item.Attrib.Type];

                    if (tinst.FixedSize)
                    {
                        item.Type.Size = tinst.Size;
                    }
                    else
                    {
                        if (!item.Type.FixedSize && item.DynamicTypeSizeProperty != null)
                            item.Type.Size = Convert.ToInt32(item.DynamicTypeSizeProperty.Getter(r));
                        else
                            item.Type.Size = item.Attrib.TypeSize;
                    }
                    
                    if (item.DynamicArraySizeProperty != null || item.Attrib.ArraySize > 0)
                    {
                        if(typeof(IList).IsAssignableFrom(item.Property.PropertyType))
                            ReadListPrimitive(r, item);
                        else
                            ReadArrayPrimitive(r, item);

                        continue;
                    }

                    ReadPrimitive(r, item);
                }
                else
                {
                    if (item.DynamicArraySizeProperty != null || item.Attrib.ArraySize > 0)
                    {
                        if(typeof(IList).IsAssignableFrom(item.Property.PropertyType))
                            ReadListType(schemeName,r, item);
                        else
                            ReadArrayType(schemeName,r, item);

                        continue;
                    }

                    item.Setter(r, ReadType(schemeName,item));
                }
            }

            return r;
        }

        private T _Deserialize<T>(string schemeName)
        {
            return (T)Deserialize(schemeName, typeof(T), typeStorage.GetTypeInfo(schemeName,typeof(T), TypeInstanceMap));
        }
        
        private void ReadListPrimitive(object c, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = (int)prop_data.DynamicArraySizeProperty.Getter(c);
            
            IList r = (IList)Activator.CreateInstance(prop_data.Property.PropertyType);

            for (int i = 0; i < arr_len; i++)
            {
                r.Add(prop_data.Type.GetValue(ref buffer, (int)offset));

                offset += prop_data.Type.Size;
            }

            prop_data.Setter(c, r);
        }

        private void ReadArrayPrimitive(object c, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = (int)prop_data.DynamicArraySizeProperty.Getter(c);
            
            Array r = Array.CreateInstance(prop_data.Attrib.Type,arr_len);

            for (int i = 0; i < arr_len; i++)
            {
                r.SetValue(prop_data.Type.GetValue(ref buffer, (int)offset),i);

                offset += prop_data.Type.Size;
            }

            prop_data.Setter(c, r);
        }
        
        private void ReadPrimitive(object c, PropertyData prop_data)
        {
            var v = prop_data.Type.GetValue(ref buffer, offset);

            if (prop_data.Property.PropertyType.IsEnum)
            {
                prop_data.Setter(c, Enum.ToObject(prop_data.Property.PropertyType, v));
                offset += prop_data.Type.Size;
                return;
            }

            prop_data.Setter(c, v);
            offset += prop_data.Type.Size;
        }
        
        private void ReadListType(string schemeName, object c, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = (int)prop_data.DynamicArraySizeProperty.Getter(c);

            //Array r = Array.CreateInstance(prop_data.Attrib.Type, arr_len);
            
            IList r = (IList)Activator.CreateInstance(prop_data.Property.PropertyType);

            for (int i = 0; i < arr_len; i++)
            {
                r.Add(ReadType(schemeName,prop_data));
            }

            prop_data.Setter(c, r);

        }

        private void ReadArrayType(string schemeName, object c, PropertyData prop_data)
        {
            int arr_len = prop_data.Attrib.ArraySize;
            if (prop_data.DynamicArraySizeProperty != null)
                arr_len = (int)prop_data.DynamicArraySizeProperty.Getter(c);

            Array r = Array.CreateInstance(prop_data.Attrib.Type, arr_len);

            for (int i = 0; i < arr_len; i++)
            {
                 r.SetValue(ReadType(schemeName, prop_data),i);
            }

            prop_data.Setter(c, r);

        }

        private object ReadType(string schemeName, PropertyData prop_data)
        {
            return Deserialize(schemeName, prop_data.Attrib.Type, typeStorage.GetTypeInfo(schemeName, prop_data.Attrib.Type, TypeInstanceMap));
        }
    }
}
