﻿using BinarySerializer.DefaultTypes;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace BinarySerializer
{
    public class PropertyData
    {
        public PropertyInfo Property { get; set; }
        public BinaryAttribute Attrib { get; set; }

        public BasicType Type { get; set; }

        public int Size { get; set; }

        public PropertyData DynamicTypeSizeProperty { get; set; }

        public PropertyData DynamicArraySizeProperty { get; set; }

        public Action<object, object> Setter { get; set; }
        public Func<object, object> Getter { get; set; }

        public PropertyData(PropertyInfo property, Dictionary<Type, BasicType> TypeInstanceMap, BinaryAttribute attrib)
        {
            Property = property;
            Attrib = attrib;
            if (TypeInstanceMap.ContainsKey(attrib.Type))
            { Type = TypeInstanceMap[attrib.Type];
                Size = Type.Size;
            }
        }

        public void CheckTypeLen(List<PropertyData> PropertyList)
        {
            if (!Type.FixedSize && Attrib.TypeSizeName != null)
            {
                DynamicTypeSizeProperty = PropertyList.Find(x=>x.Property.Name == Attrib.TypeSizeName);
                return;
            }

            Type.Size = Attrib.TypeSize;
        }

        public void CheckArrayLen(List<PropertyData> PropertyList)
        {
            if (Attrib.ArraySizeName != null)
            {
                DynamicArraySizeProperty = PropertyList.Find(x => x.Property.Name == Attrib.ArraySizeName);
            }
        }

        public void SetMethods(Action<object, object> setter, Func<object, object> getter)
        {
            Getter = getter;
            Setter = setter;
        }

        public override string ToString()
        {
            return $"{Property.Name}";
        }
    }
}
