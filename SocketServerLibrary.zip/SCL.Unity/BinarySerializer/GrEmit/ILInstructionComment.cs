namespace GrEmit
{
    internal abstract class ILInstructionComment : ILInstructionParameter
    {
    }
}