namespace GrEmit
{
    internal abstract class ILInstructionParameter
    {
        public abstract string Format();
    }
}