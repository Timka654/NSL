﻿namespace GrEmit.StackMutators
{
    internal class RethrowStackMutator : StackMutator
    {
        public override void Mutate(GroboIL il, ILInstructionParameter parameter, ref EvaluationStack stack)
        {
        }
    }
}