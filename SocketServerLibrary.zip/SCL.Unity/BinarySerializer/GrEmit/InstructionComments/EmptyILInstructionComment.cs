namespace GrEmit.InstructionComments
{
    internal class EmptyILInstructionComment : ILInstructionComment
    {
        public override string Format()
        {
            return "";
        }
    }
}