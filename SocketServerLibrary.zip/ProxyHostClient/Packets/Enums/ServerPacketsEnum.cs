﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyHostClient.Packets.Enums
{
    internal enum ServerPacketsEnum
    {
        GetProxyServer = 1,
        PlayerConnectedResult,
        PlayerDisconnected
    }
}
