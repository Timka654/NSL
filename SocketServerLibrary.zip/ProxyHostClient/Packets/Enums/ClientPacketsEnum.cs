﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyHostClient.Packets.Enums
{
    public enum ClientPacketsEnum
    {
        SignInResult = 1,
        PlayerConnected,
        PlayerDisconnected,
        GetProxyServerResult,
    }
}
