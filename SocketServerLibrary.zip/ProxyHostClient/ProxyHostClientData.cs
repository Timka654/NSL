﻿using SocketServer.Utils;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyHostClient
{
    public class ProxyHostClientData : INetworkClient
    {
    }
}
