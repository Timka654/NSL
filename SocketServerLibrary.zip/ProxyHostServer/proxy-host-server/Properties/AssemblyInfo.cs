﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Общие сведения об этой сборке предоставляются следующим набором 
// атрибутов. Отредактируйте значения этих атрибутов, чтобы изменить
// общие сведения об этой сборке.
[assembly: AssemblyTitle("proxy-host-server")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("debug")]
[assembly: AssemblyCompany("AppFox")]
[assembly: AssemblyProduct("proxy-host-server")]
[assembly: AssemblyCopyright("AppFox ©  2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Установка значения False в параметре ComVisible делает типы в этой сборке невидимыми 
// для COM-компонентов.  Если необходим доступ к типу в этой сборке из 
// COM, следует установить атрибут ComVisible в TRUE для этого типа.
[assembly: ComVisible(false)]

// Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
[assembly: Guid("746f5ca1-3bde-4d4b-9ab4-6dc146050b2a")]

// Сведения о версии сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//   Номер сборки
//      Редакция
//
[assembly: AssemblyVersion("0.1.*")]
[assembly: AssemblyFileVersion("0.1")]
