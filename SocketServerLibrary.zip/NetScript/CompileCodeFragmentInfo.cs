﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetScript
{
    public class CompileCodeFragmentInfo
    {
        public int Start { get; set; }

        public int End { get; set; }

        public string FileName { get; set; }
    }
}
