﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace $rootnamespace$
{
    /// <summary>
    /// $model_summary$
    /// </summary>
    public partial class $safeitemname$ : IEntityTypeConfiguration<$safesrcitemname$>
    {
        public void Configure(EntityTypeBuilder<$safesrcitemname$> builder)
        {
            
        }
    }
}
