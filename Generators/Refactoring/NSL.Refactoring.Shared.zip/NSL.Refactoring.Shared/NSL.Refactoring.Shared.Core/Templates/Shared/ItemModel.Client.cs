﻿#if CLIENT

namespace $rootnamespace$
{
    /// <summary>
    /// $model_summary$
    /// </summary>
    public partial class $safeitemname$
    {
    }
}

#endif