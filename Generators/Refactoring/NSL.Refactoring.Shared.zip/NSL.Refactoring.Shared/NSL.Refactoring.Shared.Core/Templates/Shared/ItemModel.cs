﻿namespace $rootnamespace$
{
    /// <summary>
    /// $model_summary$
    /// </summary>
    public partial class $safeitemname$
    {
    }
}
