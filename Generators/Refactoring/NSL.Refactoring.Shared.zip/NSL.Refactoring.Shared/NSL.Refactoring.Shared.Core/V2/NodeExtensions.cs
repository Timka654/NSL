﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Syntax;
namespace NSL.Refactoring.Shared.Core.V2
{
    internal static class NodeExtensions
    {
        public static NamespaceDeclarationSyntax GetParentNamespace(this SyntaxNode node)
        {
            SyntaxNode currentNode = node;

            while (currentNode != null && (currentNode is NamespaceDeclarationSyntax))
            {
                currentNode = currentNode.Parent;
            }
            return currentNode as NamespaceDeclarationSyntax;
        }
    }
}
