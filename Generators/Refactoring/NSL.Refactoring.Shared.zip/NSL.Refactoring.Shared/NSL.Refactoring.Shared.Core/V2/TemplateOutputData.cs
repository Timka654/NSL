﻿using System.Collections.Generic;
namespace NSL.Refactoring.Shared.Core.V2
{
    internal class TemplateOutputData
    {
        public TemplateData Template { get; set; }

        public Dictionary<string, string> Values { get; set; }

        public string OutputPath { get; set; }

        public string NameSpace { get; set; }
    }
}
