﻿namespace NSL.Refactoring.Shared.Core.V2
{
    public class TemplateFileData
    {
        public string Name { get; set; }
        public string Content { get; set; }
    }


}
