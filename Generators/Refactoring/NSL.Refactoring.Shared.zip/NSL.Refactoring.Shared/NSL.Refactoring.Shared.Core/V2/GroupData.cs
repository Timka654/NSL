﻿using Microsoft.CodeAnalysis;

namespace NSL.Refactoring.Shared.Core.V2
{
    public class GroupData
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string ProjectName { get; set; }

        public string[] Actions { get; set; }

        public Project Project { get; set; }

        public string ProjectPath { get; set; } = default;

        public bool Disabled { get; set; } = false;
    }


}
