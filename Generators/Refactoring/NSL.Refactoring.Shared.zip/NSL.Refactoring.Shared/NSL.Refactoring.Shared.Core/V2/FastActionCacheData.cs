﻿namespace NSL.Refactoring.Shared.Core.V2
{
    internal class FastActionCacheData { 
        public string ProjectPath { get; set; } = default;
        
        public string SolutionPath { get; set; } = default;

        public FastActionData Data { get; set; }
    }


}
