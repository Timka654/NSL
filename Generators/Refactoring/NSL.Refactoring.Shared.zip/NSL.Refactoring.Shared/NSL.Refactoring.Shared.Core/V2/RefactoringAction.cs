﻿namespace NSL.Refactoring.Shared.Core.V2
{
    internal class RefactoringAction
    {
        public PreviewedCodeAction.ActionDelegate Action { get; set; }

        public string Path { get; set; }
    }
}
