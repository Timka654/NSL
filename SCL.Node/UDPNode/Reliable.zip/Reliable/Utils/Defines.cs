﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReliableNetcode.Utils
{
	internal static class Defines
	{
		public const int MAX_PACKET_HEADER_BYTES = 10;
		public const int FRAGMENT_HEADER_BYTES = 6;
	}
}
